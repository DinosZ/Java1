// File: SnackBar
// Description: Snack bar
// Assignment Number: Ch6-3
//
// ID: 6888040
// Name: Worapol Khaeso
// Section: 2
// Grader: 
//
// On my honor, Worapol Khaeso, this lab assignment is my own work
// and I have not provided this code to any other students.
public class SnackBar extends Food{
	private String brand;
	
	public SnackBar(String name, int level, double price, String brand) {
		super(name, level, price);
		this.brand = brand;
	}
	
	public String getBrand() {
        return brand;
    }
	
	
	public void printInfo() {
        super.printInfo();
        System.out.println("Brand: " + brand);
    }
}
