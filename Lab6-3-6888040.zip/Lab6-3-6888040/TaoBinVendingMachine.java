// File: TaoBinVendingMachine
// Description: Taobin
// Assignment Number: Ch6-3
//
// ID: 6888040
// Name: Worapol Khaeso
// Section: 2
// Grader: 
//
// On my honor, Worapol Khaeso, this lab assignment is my own work
// and I have not provided this code to any other students.


/* Instruction: Make sure you read the comment properly and implement exactly what we asked…(Yes, this is a test). 
 *  You can modify parameters, variable name, access level, return type but not the method names in all classes we provided */

import java.util.ArrayList;

public class TaoBinVendingMachine {
    private ArrayList<Food> menu = new ArrayList<>();
    
    public void addItem(Food item) { 
    	menu.add(item); 
    }
    
    public TaoBinVendingMachine( ) {
        // Do something?
    	this.menu = new ArrayList<>();
    }
    
    public TaoBinVendingMachine(ArrayList<Food> menu) {
    	this.menu = menu;
    }

    // TODO 1: implement printMenu()
    // Example:
    // [0] Iced Latte - 45.0 THB
    // [1] Thai Milk Tea - 40.0 THB
    public void printDrinkMenu() {
        System.out.println("--- Drink Menu ---");
        for (int i = 0; i < menu.size(); i++) {
            // If it's NOT a SnackBar, it's a drink
            if (!(menu.get(i) instanceof SnackBar)) {
                System.out.println("[" + i + "] " + menu.get(i).name);
            }
        }
    }
    public void printSnackMenu() {
        System.out.println("--- Snack Menu ---");
        for (int i = 0; i < menu.size(); i++) {
            // If it's a SnackBar, display it
            if (menu.get(i) instanceof SnackBar) {
                System.out.println("[" + i + "] " + menu.get(i).name);
            }
        }
    }
    public void printFullMenu() {
        System.out.println("--- Full Menu ---");
        for (int i = 0; i < menu.size(); i++) {
            System.out.println("[" + i + "] " + menu.get(i).name);
        }
    }

    // TODO 2: implement selectItem(int index)
    // If valid:
    //   print "Selected:" then call menu.get(index).printInfo()
    // Else:
    //   print "Invalid selection"
    public void selectItem(int index) {
        if (index >= 0 && index < menu.size()) {
            System.out.print("Selected: ");
            menu.get(index).printInfo();
        } else {
            System.out.println("Invalid selection");
        }
    }
}

