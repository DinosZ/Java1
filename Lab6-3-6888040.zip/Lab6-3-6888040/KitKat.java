// File: KitKat
// Description: snack 3
// Assignment Number: Ch6-3
//
// ID: 6888040
// Name: Worapol Khaeso
// Section: 2
// Grader: 
//
// On my honor, Worapol Khaeso, this lab assignment is my own work
// and I have not provided this code to any other students.
public class KitKat extends SnackBar {
	private int fingers;
	
	public KitKat(String name, int level, double price, int fingers) {
		super(name, level, price, "Nestle");
        this.fingers = fingers;
	}

	public void printInfo() {
        super.printInfo();
        System.out.println("Fingers: " + fingers);
    }
}
