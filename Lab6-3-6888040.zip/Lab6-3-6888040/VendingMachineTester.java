/*
 *  This is the main testing class ,you should not modify it 
 *  */
import java.util.Scanner;

public class VendingMachineTester {
    public static void main(String[] args) {
    	TaoBinVendingMachine vm = new TaoBinVendingMachine();
    	Scanner sc = new Scanner(System.in);
    	
    	vm.addItem(new TaoBinDrink("Iced Latte", 3, 45.0, 50));
        vm.addItem(new FeastAble("FeastAble", 5, 99.0, 45));
        vm.addItem(new MySnaxx("MySnaxx", 2, 25.0, 60.5));
        vm.addItem(new KitKat("KitKat 4-Finger", 4, 30.0, 4));
        

        while (true) {
            System.out.println("\n--- TaoBin Vending Machine (Challenge) ---");
            System.out.println("1: Show Drink Menu");
            System.out.println("2: Show Snack Menu");
            System.out.println("3: Show Full Menu");
            System.out.println("4: Select Item by Index");
            System.out.println("5: Exit");
            System.out.print("Please choose an action: ");
            
            int choice = sc.nextInt(); // รับค่าตัวเลือกจากผู้ใช้

            if (choice == 1) {
                vm.printDrinkMenu(); // แสดงเฉพาะเครื่องดื่ม 
            } 
            else if (choice == 2) {
                vm.printSnackMenu(); // แสดงเฉพาะขนม 
            } 
            else if (choice == 3) {
                vm.printFullMenu(); // แสดงเมนูทั้งหมด 
            } 
            else if (choice == 4) {
                System.out.print("Enter item index: ");
                int index = sc.nextInt();
                vm.selectItem(index); // เลือกสินค้าตาม Index 
            } 
            else if (choice == 5) {
                System.out.println("Thank you! Goodbye."); // ออกจากโปรแกรม 
                break; 
            } 
            else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
        sc.close(); // ปิด Scanner เมื่อจบการทำงาน
    }
}
