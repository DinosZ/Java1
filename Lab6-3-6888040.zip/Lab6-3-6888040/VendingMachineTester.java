/*
 *  This is the main testing class ,you should not modify it 
 *  */

public class VendingMachineTester {
    public static void main(String[] args) {
    	TaoBinVendingMachine vm = new TaoBinVendingMachine();

    	vm.addItem(new TaoBinDrink("Iced Latte", 3, 45.0, 50));
        vm.addItem(new FeastAble("FeastAble", 5, 99.0, 45));
        vm.addItem(new MySnaxx("MySnaxx", 2, 25.0, 60.5));
        vm.addItem(new KitKat("KitKat 4-Finger", 4, 30.0, 4));

        System.out.println("--- Testing Drink Menu ---");
        vm.printDrinkMenu();
        System.out.println("\n--- Testing: Snack Menu ---");
        vm.printSnackMenu();
        System.out.println("\n--- Testing: Selection ---");
        vm.selectItem(1);
    }
}
