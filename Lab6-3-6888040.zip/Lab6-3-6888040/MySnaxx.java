// File: MySnaxx
// Description: snack 2
// Assignment Number: Ch6-3
//
// ID: 6888040
// Name: Worapol Khaeso
// Section: 2
// Grader: 
//
// On my honor, Worapol Khaeso, this lab assignment is my own work
// and I have not provided this code to any other students.
public class MySnaxx extends SnackBar {
	private double weight;
	
	public MySnaxx(String name, int level, double price, double weight) {
		super(name, level, price, "MyMateNate");
        this.weight = weight;
	}
	
	public void printInfo() {
        super.printInfo();
        System.out.println("MySnaxx: " + weight + "g");
    }

}

