// File: FeastAble
// Description: snack 1
// Assignment Number: Ch6-3
//
// ID: 6888040
// Name: Worapol Khaeso
// Section: 2
// Grader: 
//
// On my honor, Worapol Khaeso, this lab assignment is my own work
// and I have not provided this code to any other students.
public class FeastAble extends SnackBar{
	private int cocoaPercentage;
	
	public FeastAble(String name, int level, double price, int cocoa) {
		super(name, level, price, "Feastables");
        this.cocoaPercentage = cocoa;
	}
	
	public void printInfo() {
        super.printInfo();
        System.out.println("Cocoa: " + cocoaPercentage + "%");
    }

}
